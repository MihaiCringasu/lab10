using SQLite;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cringasu_Mihai_Razvan_Lab9.Models;

namespace Cringasu_Mihai_Razvan_Lab9.Data
{
    public class ShopListDatabase
    {
        readonly SQLiteAsyncConnection _database;

        public ShopListDatabase(string dbPath)
        {
            _database = new SQLiteAsyncConnection(dbPath);
            _database.CreateTableAsync<ShopList>().Wait();
            _database.CreateTableAsync<Product>().Wait();
            _database.CreateTableAsync<ListProduct>().Wait();
            _database.CreateTableAsync<Shop>().Wait();
        }

        public Task<List<Shop>> GetShopsAsync()
        {
            return _database.Table<Shop>().ToListAsync();
        }

        public Task<int> SaveShopAsync(Shop shop)
        {
            if (shop.ID != 0)
                return _database.UpdateAsync(shop);
            else
                return _database.InsertAsync(shop);
        }

        public Task<int> DeleteShopAsync(Shop shop)
        {
            return _database.DeleteAsync(shop);
        }
    }
}