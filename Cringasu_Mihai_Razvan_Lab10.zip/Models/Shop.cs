using SQLite;
using SQLiteNetExtensions.Attributes;
using System.Collections.Generic;

namespace Cringasu_Mihai_Razvan_Lab9.Models
{
    public class Shop
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string ShopName { get; set; }
        public string Address { get; set; }
        public string ShopDetails { get { return ShopName + " " + Address; } }
        [OneToMany]
        public List<ShopList> ShopLists { get; set; }
    }
}