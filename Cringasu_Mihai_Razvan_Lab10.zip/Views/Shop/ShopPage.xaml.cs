using System;
using Xamarin.Forms;
using Cringasu_Mihai_Razvan_Lab9.Models;

namespace Cringasu_Mihai_Razvan_Lab9.Views
{
    public partial class ShopPage : ContentPage
    {
        public ShopPage()
        {
            InitializeComponent();
        }

        async void OnSaveButtonClicked(object sender, EventArgs e)
        {
            var shop = (Shop)BindingContext;
            await App.Database.SaveShopAsync(shop);
            await Navigation.PopAsync();
        }

        async void OnDeleteButtonClicked(object sender, EventArgs e)
        {
            var shop = (Shop)BindingContext;
            if (shop != null)
            {
                await App.Database.DeleteShopAsync(shop);
                await Navigation.PopAsync();
            }
        }
    }
}